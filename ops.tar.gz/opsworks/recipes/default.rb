#
# Cookbook:: opsworks
# Recipe:: default
#
# Copyright:: 2019, The Authors, All Rights Reserved.

Chef::Log.info("******* Hello, World! ******")
